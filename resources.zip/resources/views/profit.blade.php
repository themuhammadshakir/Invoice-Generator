@extends('layout')
@section('content')
<div class="card">
    <div class="card-header"><h2>Profit</h2></div>
    <div class="card-body">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product_Name</th>
                        <th>Unit Price</th>
                        <th>Total_Amount</th>
                        <th>Sold_Quantity</th>
                        <th>Expense</th>
                        <th>Profit</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($products as $item)
                        <tr>
                            <td>{{ $item->name }}</td>
                            <td>{{ $item->unit_price }}</td>    
                            <td>{{ $item->amount}}</td>  
                            <td>{{ $item->sold_quantity  }}</td> 
                            <td>{{ ($item->sold_quantity) * ($item->unit_price )  }}</td>
                            <td>{{ ($item->amount) - ($item->sold_quantity) * ($item->unit_price ) }}</td>    
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection