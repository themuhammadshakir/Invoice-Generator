@extends('layout')
@section('content')
<div class="card">
    <div class="card-header">Invoices</div>
    <div class="card-body">
        <div class="card-body">
          
            <h5 class="card-title">Product : {{ $invoices->product  }}</h5>
            <p class="card-text">Amount: {{ $invoices->amount}}</p>
            <p class="card-text">Quantity : {{ $invoices->sold_quantity }}</p>
            <p class="card-text">Discount: {{ $invoices->discount}}</p>
            <p class="card-text">Date : {{ $invoices->date }}</p>

        </div>
    </div>
</div>
@endsection
