@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">
        <h2>Invoices</h2>
    </div>
    <div class="card-body">
        <a href="{{ url('/invoice/create') }}" class="btn btn-success btn-sm" title="Add New invoice">
            <i class="fa fa-plus" aria-hidden="true"></i> Add New
        </a>
        <br />
        <br />
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product</th>
                        <th>Amount</th>
                        <th>Quantity</th>
                        <th>Discount</th>
                        <th>Total_Amount</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($invoices as $item)
                
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->product }}</td>
                        <td>{{ ($item->amount)+($item->discount) }}</td>
                        <td>{{ $item->sold_quantity }}</td>
                        <td>{{ $item->discount }}</td>
                        <td>{{ ($item->amount)}}</td>
                        <td>{{ $item->date }}</td>  

                        <td>
                            <a href="{{ url('/invoice/' . $item->id) }}" title="View invoice">
                            <button class="button">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                                    </button></a>
                            <a href="{{ url('/invoice/' . $item->id . '/edit') }}" title="Edit invoice"><button class="button"><i class="fa-solid fa-pen-to-square"></i> </button></a>

                            <form method="POST" action="{{ url('/invoice' . '/' . $item->id) }}" accept-charset="UTF-8"
                                style="display:inline">
                                {{ method_field('DELETE') }}
                                {{ csrf_field() }}
                                <button type="submit" class="button" title="Delete invoice"
                                    onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash"></i> </button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection