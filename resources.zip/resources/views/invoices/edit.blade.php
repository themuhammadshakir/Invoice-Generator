@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">Invoice Edit</div>
    <div class="card-body">
        <form action="{{ url('invoice/' .$invoices->id) }}" method="post">
            {!! csrf_field() !!}
            @method("PATCH")
            <input type="hidden" name="id" id="id" value="{{$invoices->id}}" id="id" />
            <label>Product_Name</label></br>
            <select name='product' id="name" value="{{$invoices->name}}" class='form-control'></br></br>
                @foreach($products as $product)
                    <option>{{$product->name}}
                @endforeach
            </select>
            <label>Quantity</label></br>
            <input type="int" name="sold_quantity" id="sold_quantity" value="{{$invoices->sold_quantity}}" class="form-control"></br>
            <label>Discount</label></br>
            <select name='discount' class='form-control'></br></br>
                <option value="0">No</option>
                <option value="5">5%</option>
                <option value="10">10%</option>
            </select>
            <label>Date</label></br>
            <input type="text" name="date" id="date" value="{{$invoices->date}}" class="form-control"></br>
            <input type="submit" value="Update" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
@stop