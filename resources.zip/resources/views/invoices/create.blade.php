@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">Invoices</div>
    <div class="card-body">
        <form action="{{ url('invoice') }}" method="post">
            {!! csrf_field() !!}
            <label> Product_ID</label></br>
            <select name='product' class='form-control'></br></br>
                @foreach($products as $product)
                    <option>{{$product->name}}
                @endforeach
            </select>
            <input type="hidden" name="amount" id="amount" class="form-control"></br>
            <br><label>Quantity</label></br>
            <input type="number" name="sold_quantity" id="sold_quantity" class="form-control"></br>
            <label>Discount</label></br>
            <select name='discount'  class='form-control'></br></br>
                <option value="0">No</option>
                <option value="5">5%</option>
                <option value="10">10%</option>
            </select>
            <label>Date</label></br>
            <input type="date" name="date" id="date" class="form-control"></br>
            <input type="submit" value="Save" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
@endsection