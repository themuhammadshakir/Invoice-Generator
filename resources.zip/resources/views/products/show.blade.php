@extends('layout')
@section('content')
<div class="card">
    <div class="card-header">Products</div>
    <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Name : {{ $products->name }}</h5>
            <p class="card-text">Description : {{ $products->description }}</p>
            <p class="card-text">Unit_Price : {{ $products->unit_price }}</p>
            <p class="card-text">Sell_Price : {{ $products->sell_price }}</p>
            <p class="card-text">Quantity : {{ $products->total_quantity }}</p>  
        </div>
    </div>
</div>
@endsection
