@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">
        <h2>Products</h2>
    </div>
    <div class="card-body">
        <a href="{{ url('/product/create') }}" class="btn btn-success btn-sm" title="Add New product">
            <i class="fa fa-plus" aria-hidden="true"></i> Add New
        </a>
        <br />
        <br />
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Vendor_Name</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Unit_Price</th>
                        <th>Sell_Price</th>
                        <th>Quantity</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($products as $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->vendor_name }}</td>
                        <td>{{ $item->name }}</td>
                        <td>{{ $item->description }}</td>
                        <td>{{ $item->unit_price }}</td>
                        <td>{{ $item->sell_price }}</td>
                        <td>{{ $item->total_quantity }}</td>

                        <td>
                            <a href="{{ url('/product/' . $item->id) }}" title="View product"><button
                            class="button"><i class="fa fa-eye" aria-hidden="true"></i>
                                    </button></a>
                            <a href="{{ url('/product/' . $item->id . '/edit') }}" title="Edit product"><button
                            class="button"><i class="fa-solid fa-pen-to-square"></i></button></a>

                            <form method="POST" action="{{ url('/product' . '/' . $item->id) }}" accept-charset="UTF-8"
                                style="display:inline">
                                {{ method_field('DELETE') }}
                                {{ csrf_field() }}
                                <button type="submit" class="button" title="Delete product"
                                    onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection