@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">Products</div>
    <div class="card-body">
        <form action="{{ url('product') }}" method="post">
            {!! csrf_field() !!}
            <label>Vendor_Name</label></br>
            <select name='vendor_name' id='vendor_name' class='form-control'></br></br>
                @foreach($vendors as $vendor)
                    <option>{{ $vendor->name }}</option>
                @endforeach
            </select>
            <label>Name</label></br>
            <input type="text" name="name" id="name" class="form-control"></br>
            <label>Description</label></br>
            <input type="text" name="description" id="description" class="form-control"></br>
            <label>Unit_Price</label></br>
            <input type="number" name="unit_price" id="unit_price" class="form-control"></br>
            <label>Sell_Price</label></br>
            <input type="number" name="sell_price" id="sell_price" class="form-control"></br>
            <label>Quantity</label></br>
            <input type="number" name="total_quantity" id="total_quantity" class="form-control"></br>
            <input type="submit" value="Save" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
@endsection