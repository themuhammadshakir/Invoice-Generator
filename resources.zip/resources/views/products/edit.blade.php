@extends('layout')
@section('content')

<div class="card">
    <div class="card-header">Product</div>
    <div class="card-body">
        <form action="{{ url('product/' .$products->id) }}" method="post">
            {!! csrf_field() !!}
            @method("PATCH")
            <input type="hidden" name="id" id="id" value="{{$products->id}}" id="id" />
            <label>Name</label></br>
            <input type="text" name="name" id="name" value="{{$products->name}}" class="form-control"></br>
            <label>Description</label></br>
            <input type="text" name="description" id="description" value="{{$products->description}}" class="form-control"></br>
            <label>Unit_Price</label></br>
            <input type="text" name="unit_price" id="unit_price" value="{{$products->unit_price}}" class="form-control"></br>
            <label>Sell_Price</label></br>
            <input type="text" name="sell_price" id="sell_price" value="{{$products->sell_price}}" class="form-control"></br>
            <label>Quantity</label></br>
            <input type="number" name="total_quantity" id="total_quantity" value="{{$products->total_quantity}}" class="form-control"></br>
            <input type="submit" value="Update" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
@stop