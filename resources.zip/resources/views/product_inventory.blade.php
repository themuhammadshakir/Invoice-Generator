@extends('layout')
@section('content')
<div class="card">
    <div class="card-header"><h2>ProductInventory</h2></div>
    <div class="card-body">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product_Name</th>
                        <th>Vendor_Name</th>
                        <th>Total Quantity</th>
                        <th>Sell Quantity</th>
                        <th>Pending</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($products as $item)
                        <tr>
                            <td>{{ $item->name }}</td>
                            <td>{{ $item->vendor_name }}</td>
                            <td>{{ $item->total_quantity }}</td>
                            <td>{{ $item->sold_quantity }}</td>
                            <td>{{($item->total_quantity)-($item->sold_quantity )}}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection