<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Product;
use App\Models\Invoice;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductInventory extends Model
{
   
    protected $table = 'product_inventories';
    protected $fillable = ['name','description','vendor_name','total_quantity','sell_price','unit_price','sold_quantity','pending'];

    use HasFactory;

    public function product(): BelongsTo
    {
            return $this->belongsTo(Product::class,'name','name');
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class,'name','product');
    }
    
}
