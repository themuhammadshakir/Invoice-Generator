<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Product;

class Invoice extends Model
{
    protected $table = 'invoices';
    protected $fillable = ['product','amount','sold_quantity','discount','date'];
    use HasFactory;

    public function product():  BelongsTo
    {
        return $this->belongsTo(Product::class,'product', 'name');
    }
    
}   