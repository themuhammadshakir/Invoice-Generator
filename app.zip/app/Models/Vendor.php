<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class Vendor extends Model
{
    protected $table = 'vendors';
    protected $fillable = ['name','address','phone_no','total_amount','product_name'];
    use HasFactory;

   

}
