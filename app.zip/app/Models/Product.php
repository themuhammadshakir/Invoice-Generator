<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Vendor;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Product extends Model
{
    protected $table = "products";
    protected $fillable = ['vendor_name','name','description','unit_price','total_quantity','sell_price'];
    use HasFactory;

    public function vendor():  BelongsTo
    {
        return $this->belongsTo(Vendor::class,'vendor_name', 'name');
    }

    
}