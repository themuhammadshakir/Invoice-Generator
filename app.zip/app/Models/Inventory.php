<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Inventory extends Model
{
    protected $table = 'inventories';

    protected $primary_key = 'id';
    protected $fillable = ['name','vendor_name','description','unit_price','total_quantity',
                            'amount','sold_quantity','discount','date'];

    use HasFactory;
}
