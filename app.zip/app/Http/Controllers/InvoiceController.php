<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\Product;
use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class InvoiceController extends Controller
{

    public function index(): View
    {
        $invoices = Invoice::all();
        return view('invoices.index')->with('invoices', $invoices);
    }


    public function create(): View
    {
        $products = Product::all();

        return view('invoices.create', compact('products'));
    }

    public function store(Request $request)
    {
        $input = $request->all();

        
        $product = Product::where('name', $input['product'])->get();
        $amount = $product[0]->sell_price * $input['sold_quantity'];
        
        $input['amount'] = $amount - ($amount * ($input['discount']/100));
        $input['discount'] = ($amount * ($input['discount']/100));
        $inventory = Inventory::where('name', $input['product'])->first();

        $inventory_1 = Inventory::findOrFail($inventory['id']);
        
        $inventory_1['sold_quantity'] = $inventory_1['sold_quantity'] + $input['sold_quantity'];

        $inventory_1->save();

        Invoice::create($input);
        
        return redirect('invoice');

        
    }
    public function show(string $id): View
    {
        $invoice = Invoice::find($id);
        return view('invoices.show')->with('invoices', $invoice);
    }

    public function edit(string $id): View
    {
        $invoices = Invoice::find($id);
        $products = Product::get();
        return view('invoices.edit', compact('invoices', 'products'));

    }
    public function update(Request $request, string $id): RedirectResponse
    {
        $invoices = Invoice::find($id);
        $input = $request->all();
        $product = Product::where('name', $input['product'])->get();
       
        $amount = $product[0]->sell_price * $input['sold_quantity'];
        
        $input['amount'] = $amount - ($amount * ($input['discount']/100));
        $input['discount'] = ($amount * ($input['discount']/100));
        $inventory = Inventory::where('name', $input['product'])->first();

        $inventory_1 = Inventory::findOrFail($inventory['id']);
        
        $inventory_1['sold_quantity'] = $inventory_1['sold_quantity'] + $input['sold_quantity'];

        $inventory_1->save();
        $invoices->update($input);
        return redirect('invoice')->with('flash_message', 'invoice Updated!');
    }

    public function destroy(string $id): RedirectResponse
    {
        Invoice::destroy($id);
        Inventory::destroy($id);
        return redirect('invoice')->with('flash_message', 'invoice deleted!');
    }
}