<?php

namespace App\Http\Controllers;

    
class InvoiceManagement extends Controller
{
    //
    function layout()
    { 
        return view('layout');
    }
}
