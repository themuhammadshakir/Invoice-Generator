<?php

namespace App\Http\Controllers;

use App\Models\Vendor;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class VendorController extends Controller
{

    public function index(): View
    {
        $vendors = Vendor::all();
        return view ('vendors.index')->with('vendors', $vendors);
    }

 
    public function create(): View
    {
        return view('vendors.create');
    }

  
    public function store(Request $request): RedirectResponse
    {
        $input = $request->all();
        $validated = $request->validate([ 
            'name' => 'required|string',
            'address' => 'required|string',
            'phone_no' => 'required|string',
            'total_amount' =>  'nullable|string'
        ]);
        Vendor::create($validated);
        
        return redirect('vendor')->with('flash_message', 'vendor Addedd!');
    }

    public function show(string $id): View
    {
        $vendor = Vendor::find($id);
        return view('vendors.show')->with('vendors', $vendor);
    }

    public function edit(string $id): View
    {
        $vendor = Vendor::find($id);
        return view('vendors.edit')->with('vendors', $vendor);
        
    }
    public function update(Request $request, string $id): RedirectResponse
    {
        $vendor = Vendor::find($id);
        
        $input = $request->all();
        
        $product = Product::where('vendor_name', $vendor->name)->first();

        $amount = $product->unit_price * $product->total_quantity;

        $input['total_amount'] = $amount;

        $vendor->update($input);
        return redirect('vendor')->with('flash_message', 'vendor Updated!');  
    }
    
    public function destroy(string $id): RedirectResponse
    {
        Vendor::destroy($id);
        return redirect('vendor')->with('flash_message', 'vendor deleted!'); 
    }
}