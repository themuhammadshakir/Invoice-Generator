<?php

namespace App\Http\Controllers;

use App\Models\Inventory;
use Illuminate\View\View;
use App\Models\ProductInventory;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class InventoryController extends Controller
{
    
    public function index(): View
    {
        $products = Inventory::all();
       
        
        return view('product_inventory',compact('products'));
    }
    public function profit(): View
    {
        $products = DB::table('invoices')
                    ->join('products','invoices.product','=','products.name')
                    ->select('products.name',DB::raw('SUM(products.unit_price) as unit_price'),'invoices.amount','invoices.sold_quantity')
                    ->groupBy('name','unit_price','amount','sold_quantity')
                    ->get();
    
    return view('profit', compact('products'));
    }
    
}
