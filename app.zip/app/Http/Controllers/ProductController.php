<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use App\Models\Vendor;

class ProductController extends Controller
{

    public function index(): View
    {
        $products = Product::all();
        return view('products.index')->with('products', $products);
    }


    public function create(): View
    {
        $vendors = Vendor::all();
        return view('products.create', compact('vendors'));
    }

    public function store(Request $request): RedirectResponse
    {
        $input = $request->all();
        // Product Update
        $products = Product::where('name', $input['name'])->where('vendor_name', $input['vendor_name'])->first();
        if ($products != null || $products > 0) {
            $product_record = Product::findOrFail($products['id']);
            $total_quantity = $product_record->total_quantity + $input['total_quantity'];
            $product_record->total_quantity = $total_quantity;
            $product_record->save();

            // Inventory Update
            $product_inventory = Inventory::where('name', $input['name'])->where('vendor_name', $input['vendor_name'])->first();
            if ($product_inventory != null || $product_inventory > 0) {
                $product_inventory = Inventory::findOrFail($product_inventory['id']);
                $product_inventory->total_quantity = $product_inventory->total_quantity + $input['total_quantity'];
                $product_inventory->save();
                return redirect('product');
            }
            else {
                // Inventory Add
                Inventory::create($input);
                return redirect('product');
            }

        } 
        else {
            // Product & Inventory Add
            Product::create($input);
            Inventory::create($input);
            return redirect('product');
        }
    }

    public function show(string $id): View
    {
        $product = Product::find($id);
        return view('products.show')->with('products', $product);
    }

    public function edit(string $id): View
    {
        $product = Product::find($id);
        return view('products.edit')->with('products', $product);

    }
    public function update(Request $request, string $id): RedirectResponse
    {
        $product = Product::find($id);
        $input = $request->all();
        $product->update($input);
        return redirect('product')->with('flash_message', 'product Updated!');
    }

    public function destroy(string $id): RedirectResponse
    {
        Product::destroy($id);
        Inventory::destroy($id);
        return redirect('product')->with('flash_message', 'product deleted!');
    }
}