
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Vendors</div>
    <div class="card-body">
        <div class="card-body">
            <p class="card-title">Name : <?php echo e($vendors->name); ?></p>
            <p class="card-text">Address: <?php echo e($vendors->address); ?></p>
            <p class="card-text">Phone_no : <?php echo e($vendors->phone_no); ?></p>
            <p class="card-text">Total_amount: <?php echo e($vendors->total_amount); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/vendors/show.blade.php ENDPATH**/ ?>