
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">Products</div>
    <div class="card-body">
        <form action="<?php echo e(url('product')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <label>Vendor_Name</label></br>
            <select name='vendor_name' id='vendor_name' class='form-control'></br></br>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($vendor->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label>Name</label></br>
            <input type="text" name="name" id="name" class="form-control"></br>
            <label>Description</label></br>
            <input type="text" name="description" id="description" class="form-control"></br>
            <label>Unit_Price</label></br>
            <input type="number" name="unit_price" id="unit_price" class="form-control"></br>
            <label>Sell_Price</label></br>
            <input type="number" name="sell_price" id="sell_price" class="form-control"></br>
            <label>Quantity</label></br>
            <input type="number" name="total_quantity" id="total_quantity" class="form-control"></br>
            <input type="submit" value="Save" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/products/create.blade.php ENDPATH**/ ?>