
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Invoices</div>
    <div class="card-body">
        <div class="card-body">
          
            <h5 class="card-title">Product : <?php echo e($invoices->product); ?></h5>
            <p class="card-text">Amount: <?php echo e($invoices->amount); ?></p>
            <p class="card-text">Quantity : <?php echo e($invoices->sold_quantity); ?></p>
            <p class="card-text">Discount: <?php echo e($invoices->discount); ?></p>
            <p class="card-text">Date : <?php echo e($invoices->date); ?></p>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/invoices/show.blade.php ENDPATH**/ ?>