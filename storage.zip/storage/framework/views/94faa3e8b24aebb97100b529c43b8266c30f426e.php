
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Vendor</div>
    <div class="card-body">
        <form action="<?php echo e(url('vendor')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <label>Name</label></br>
            <input type="text" name="name" id="name" class="form-control"></br>
            <label>Address</label></br>
            <input type="address" name="address" id="address" class="form-control"></br>
            <label>Phone_no</label></br>
            <input type="text" name="phone_no" id="phone_no" class="form-control"></br>
            <!-- <label>Total_amount</label></br>
            <input type="total_amount" name="total_amount" id="total_amount" class="form-control"></br> -->
            <input type="submit" value="Save" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/vendors/create.blade.php ENDPATH**/ ?>