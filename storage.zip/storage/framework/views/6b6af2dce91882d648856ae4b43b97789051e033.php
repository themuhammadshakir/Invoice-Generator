
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h2>Products</h2>
    </div>
    <div class="card-body">
        <a href="<?php echo e(url('/product/create')); ?>" class="btn btn-success btn-sm" title="Add New product">
            <i class="fa fa-plus" aria-hidden="true"></i> Add New
        </a>
        <br />
        <br />
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Vendor_Name</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Unit_Price</th>
                        <th>Sell_Price</th>
                        <th>Quantity</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->vendor_name); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td><?php echo e($item->unit_price); ?></td>
                        <td><?php echo e($item->sell_price); ?></td>
                        <td><?php echo e($item->total_quantity); ?></td>

                        <td>
                            <a href="<?php echo e(url('/product/' . $item->id)); ?>" title="View product"><button
                            class="button"><i class="fa fa-eye" aria-hidden="true"></i>
                                    </button></a>
                            <a href="<?php echo e(url('/product/' . $item->id . '/edit')); ?>" title="Edit product"><button
                            class="button"><i class="fa-solid fa-pen-to-square"></i></button></a>

                            <form method="POST" action="<?php echo e(url('/product' . '/' . $item->id)); ?>" accept-charset="UTF-8"
                                style="display:inline">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="button" title="Delete product"
                                    onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/products/index.blade.php ENDPATH**/ ?>