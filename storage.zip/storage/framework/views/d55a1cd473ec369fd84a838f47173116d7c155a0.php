
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">Product</div>
    <div class="card-body">
        <form action="<?php echo e(url('product/' .$products->id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <?php echo method_field("PATCH"); ?>
            <input type="hidden" name="id" id="id" value="<?php echo e($products->id); ?>" id="id" />
            <label>Name</label></br>
            <input type="text" name="name" id="name" value="<?php echo e($products->name); ?>" class="form-control"></br>
            <label>Description</label></br>
            <input type="text" name="description" id="description" value="<?php echo e($products->description); ?>" class="form-control"></br>
            <label>Unit_Price</label></br>
            <input type="text" name="unit_price" id="unit_price" value="<?php echo e($products->unit_price); ?>" class="form-control"></br>
            <label>Sell_Price</label></br>
            <input type="text" name="sell_price" id="sell_price" value="<?php echo e($products->sell_price); ?>" class="form-control"></br>
            <label>Quantity</label></br>
            <input type="number" name="total_quantity" id="total_quantity" value="<?php echo e($products->total_quantity); ?>" class="form-control"></br>
            <input type="submit" value="Update" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/products/edit.blade.php ENDPATH**/ ?>