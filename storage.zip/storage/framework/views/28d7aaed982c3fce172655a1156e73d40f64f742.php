
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h2>Invoices</h2>
    </div>
    <div class="card-body">
        <a href="<?php echo e(url('/invoice/create')); ?>" class="btn btn-success btn-sm" title="Add New invoice">
            <i class="fa fa-plus" aria-hidden="true"></i> Add New
        </a>
        <br />
        <br />
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product</th>
                        <th>Amount</th>
                        <th>Quantity</th>
                        <th>Discount</th>
                        <th>Total_Amount</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->product); ?></td>
                        <td><?php echo e(($item->amount)+($item->discount)); ?></td>
                        <td><?php echo e($item->sold_quantity); ?></td>
                        <td><?php echo e($item->discount); ?></td>
                        <td><?php echo e(($item->amount)); ?></td>
                        <td><?php echo e($item->date); ?></td>  

                        <td>
                            <a href="<?php echo e(url('/invoice/' . $item->id)); ?>" title="View invoice">
                            <button class="button">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                                    </button></a>
                            <a href="<?php echo e(url('/invoice/' . $item->id . '/edit')); ?>" title="Edit invoice"><button class="button"><i class="fa-solid fa-pen-to-square"></i> </button></a>

                            <form method="POST" action="<?php echo e(url('/invoice' . '/' . $item->id)); ?>" accept-charset="UTF-8"
                                style="display:inline">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="button" title="Delete invoice"
                                    onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash"></i> </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/invoices/index.blade.php ENDPATH**/ ?>