
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header"><h2>ProductInventory</h2></div>
    <div class="card-body">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product_Name</th>
                        <th>Vendor_Name</th>
                        <th>Total Quantity</th>
                        <th>Sell Quantity</th>
                        <th>Pending</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->vendor_name); ?></td>
                            <td><?php echo e($item->total); ?></td>
                            <td><?php echo e($item->sold); ?></td>
                            <td><?php echo e(($item->total)-($item->sold)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views//product_inventory.blade.php ENDPATH**/ ?>