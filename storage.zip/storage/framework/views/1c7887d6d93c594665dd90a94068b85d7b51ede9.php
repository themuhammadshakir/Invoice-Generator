
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Products</div>
    <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Name : <?php echo e($products->name); ?></h5>
            <p class="card-text">Description : <?php echo e($products->description); ?></p>
            <p class="card-text">Unit_Price : <?php echo e($products->unit_price); ?></p>
            <p class="card-text">Sell_Price : <?php echo e($products->sell_price); ?></p>
            <p class="card-text">Quantity : <?php echo e($products->total_quantity); ?></p>  
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/products/show.blade.php ENDPATH**/ ?>