
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">Invoices</div>
    <div class="card-body">
        <form action="<?php echo e(url('invoice')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <label> Product_ID</label></br>
            <select name='product' class='form-control'></br></br>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($product->name); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="hidden" name="amount" id="amount" class="form-control"></br>
            <br><label>Quantity</label></br>
            <input type="number" name="sold_quantity" id="sold_quantity" class="form-control"></br>
            <label>Discount</label></br>
            <select name='discount'  class='form-control'></br></br>
                <option value="0">No</option>
                <option value="5">5%</option>
                <option value="10">10%</option>
            </select>
            <label>Date</label></br>
            <input type="date" name="date" id="date" class="form-control"></br>
            <input type="submit" value="Save" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/invoices/create.blade.php ENDPATH**/ ?>