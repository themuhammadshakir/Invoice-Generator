
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">Vendor Edit</div>
    <div class="card-body">
        <form action="<?php echo e(url('vendor/' .$vendors->id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <?php echo method_field("PATCH"); ?>
            <input type="hidden" name="id" id="id" value="<?php echo e($vendors->id); ?>" id="id" />
            <label>Name</label></br>
            <input type="text" name="name" id="name" value="<?php echo e($vendors->name); ?>" class="form-control"></br>
            <label>Address</label></br>
            <input type="text" name="address" id="address" value="<?php echo e($vendors->address); ?>" class="form-control"></br>
            <label>Phone_no</label></br>
            <input type="text" name="phone_no" id="phone_no" value="<?php echo e($vendors->phone_no); ?>" class="form-control"></br>
            <div hidden>
                <label>Total_amount</label></br>
                <input type="text" name="total_amount" id="total_amount" value="<?php echo e($vendors->total_amount); ?>" class="form-control"></br>
            </div>
            <input type="submit" value="Update" class="btn btn-success"></br>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Invoice_Management\resources\views/vendors/edit.blade.php ENDPATH**/ ?>